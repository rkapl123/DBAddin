MySQL:
Start->Run, type cmd, cd C:\Programme\MySQL\MySQL Server <VERSION>\bin, then enter
    mysql -h localhost -u root �p
You are prompted to enter the root passwaord.
You will see the "mysql>" prompt.
Open "MySqlPubs.sql", Edit->Select All, Copy
Right click on the "mysql>" prompt, Paste
Your will see the execution of the SQL statements in "MySqlPubs.sql" to create the pubs database


Oracle:
Start->Run, type cmd, cd into the folder where the OraPubs.sql is located then enter
		sqlplus system/<systempwd> @OraPubs.sql


Sybase:
Start->Run, type cmd, cd into the folder where the SybasePubs.sql is located then enter
		isql -Usa -Psapwd -i SybasePubs.sql


DB2:
Have an OS user "db2user" available (created in Windows/Linux).
Create database "pubs"
Create user db2user in "pubs"
create database "pubs" in admin tool, then open File in CLI and execute "DB2Pubs.sql"
give access rights to all tables in schema db2user to "db2user".


PostgreSQL:
Create database "pubs" and pubsUser with: psql -U <yourAdminUser> -f pubsPgCreateUser.sql
then create tables/contents: psql -U pubsUser -f pubsPg.sql pubs
